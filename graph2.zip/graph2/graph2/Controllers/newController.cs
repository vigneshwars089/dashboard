﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using graph2.Models;

namespace graph2.Controllers
{
    public class newController : Controller
    {
        gClass1 Cdata = new gClass1();
        List<gClass1> Clist = new List<gClass1>();
        List<gClass1> Blist = new List<gClass1>();
        List<gClass1> Alist = new List<gClass1>();
        // GET: /new/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetData()
        {
            //gClass1 p = new gClass1();
            //List<gClass1> Li = new List<gClass1>();
        
            Clist = Cdata.GetData();
            ViewBag.details = Clist;
            //  ViewData["gClass1"] = Li;
            return View();
        }
        public ActionResult GetYearlyData()
        {
            //gClass1 p = new gClass1();
            //List<gClass1> Li = new List<gClass1>();
        
            Clist = Cdata.GetYearlyData();
            ViewBag.details = Clist;
            //  ViewData["gClass1"] = Li;
            return View();
        }
        public ActionResult GetQuarterlyData()
        {
            //gClass1 p = new gClass1();
            //List<gClass1> Li = new List<gClass1>();

            Clist = Cdata.GetQuarterlyData();
            ViewBag.details = Clist;
            //  ViewData["gClass1"] = Li;
            return View();
        }
        public ActionResult GetMonthlyData()
        {
            //gClass1 p = new gClass1();
            //List<gClass1> Li = new List<gClass1>();

            Clist = Cdata.GetMonthlyData();
            ViewBag.details = Clist;
            //  ViewData["gClass1"] = Li;
            return View();
        }
        public ActionResult GetWeeklyData()
        {
            //gClass1 p = new gClass1();
            //List<gClass1> Li = new List<gClass1>();

            Clist = Cdata.GetWeeklyData();
            ViewBag.details = Clist;
            //  ViewData["gClass1"] = Li;
            return View();
        }
        public ActionResult GetDailyData()
        {
            //gClass1 p = new gClass1();
            //List<gClass1> Li = new List<gClass1>();

            Clist = Cdata.GetDailyData();
            ViewBag.details = Clist;
            //  ViewData["gClass1"] = Li;
            return View();
        }

        public ActionResult last()
        {
            Clist = Cdata.GetYearlyData();
            
            //foreach(var item in Clist)
            //{
              //  int max = max(item.Year);
            //}
            ViewBag.details = Clist;
            ViewBag.Aempty = Alist;
            ViewBag.Bempty = Blist;
            return View();
        }

    }
}
