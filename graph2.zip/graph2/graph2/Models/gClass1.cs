﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.ComponentModel.DataAnnotations;
using System.Web.UI.WebControls;
using System.Data.Entity;
using System.Data.Sql;
namespace graph2.Models
{
    public class gClass1
    {
        SqlConnection con = new SqlConnection();
        List<gClass1> DataList = new List<gClass1>();
        public String AppName { get; set; }
        public Int32 TotalUsers { get; set; }
        public String Labelname { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy}")]
        public Int16 Year { get; set; }
        public DateTime Month { get; set; }
        public DateTime Day { get; set; }
        public DateTime Week { get; set; }
        public String Term { get; set; }
        gClass1 data = null;
        public List<gClass1> GetData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {

                SqlCommand cmd = new SqlCommand("select t2.ApplicationName,COUNT(t1.ApplicationID) AS num from dbo.Application as t2 inner join dbo.AccessDetails as t1  on t1.ApplicationID=t2.ApplicationID group by t2.ApplicationName", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {

                    data = new gClass1();
                    data.AppName = Convert.ToString(rd.GetSqlValue(0));

                    data.TotalUsers = Convert.ToInt32(rd.GetInt32(1));
                    DataList.Add(data);

                }
            }
            return DataList;
        }

        public List<gClass1> GetYearlyData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {
                SqlCommand cmd = new SqlCommand("SELECT t2.ApplicationName, COUNT(t1.ApplicationID),cast(DATEPART(yyyy,t1.AccessedDate) as smallint) AS OrderYear FROM dbo.AccessDetails as t1 inner join dbo.Application as t2 on t1.ApplicationID=t2.ApplicationID group by ApplicationName,DATEPART(yyyy,t1.AccessedDate)", con);

                //SqlCommand cmd = new SqlCommand("SELECT t2.ApplicationName, COUNT(t1.ApplicationID),cast(DATEPART(yyyy,t1.AccessedDate) as smallint) AS OrderYear ,t2.ApplicationName FROM dbo.AccessDetails as t1 inner join dbo.Application as t2 on t1.ApplicationID=t2.ApplicationID group by ApplicationName,DATEPART(yyyy,t1.AccessedDate)", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    
                    data = new gClass1();

                    //data.Year = Convert.ToString(rd.GetSqlValue(0));
                  
                    data.AppName = Convert.ToString(rd.GetSqlValue(0));

                    data.TotalUsers = Convert.ToInt32(rd.GetInt32(1));
                    data.Year = Convert.ToInt16(rd.GetInt16(2));
                    //data.Labelname = string.Concat(data.AppName, Convert.ToString(data.Year));
                    DataList.Add(data);

                }
            }
            return DataList;
        }
        public List<gClass1> GetQuarterlyData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {

                SqlCommand cmd = new SqlCommand("SELECT  t2.ApplicationName,COUNT(t1.ApplicationID),cast(DATEPART(yyyy,t1.AccessedDate) as smallint) AS OrderYear,DATEPART(QQ,t1.AccessedDate) AS OrderM,COUNT(t1.ApplicationID) FROM dbo.AccessDetails as t1 inner join dbo.Application as t2 on t1.ApplicationID=t2.ApplicationID group by ApplicationName,DATEPART(yyyy,t1.AccessedDate),DATEPART(QQ,t1.AccessedDate) order by DATEPART(yyyy,t1.AccessedDate),DATEPART(QQ,t1.AccessedDate)", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {

                    data = new gClass1();
                    //data.Year = Convert.ToDateTime(rd.GetDateTime(4));
                    data.AppName = Convert.ToString(rd.GetSqlValue(0));

                    data.TotalUsers = Convert.ToInt32(rd.GetInt32(1));
                    data.Year = Convert.ToInt16(rd.GetInt16(2));
                    //data.Term = Convert.ToString(rd.GetString(40));
                    //data.Term = string.Concat(rd.GetInt64(2), "Quarter");
                    DataList.Add(data);

                }
            }
            return DataList;
        }
        public List<gClass1> GetMonthlyData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {

                SqlCommand cmd = new SqlCommand("SELECT DATEPART(yyyy,t1.AccessedDate) AS OrderYear,DATEPART(MM,t1.AccessedDate) AS OrderM, t2.ApplicationName,COUNT(t1.ApplicationID) FROM dbo.AccessDetails as t1 inner join dbo.Application as t2 on t1.ApplicationID=t2.ApplicationID group by ApplicationName,DATEPART(yyyy,t1.AccessedDate),DATEPART(MM,t1.AccessedDate) order by DATEPART(yyyy,t1.AccessedDate),DATEPART(MM,t1.AccessedDate)", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {

                    data = new gClass1();
                    //data.Year = Convert.ToDateTime(rd.GetDateTime(4));
                    data.Month = Convert.ToDateTime(rd.GetDateTime(4));
                   
                    data.AppName = Convert.ToString(rd.GetSqlValue(0));

                    data.TotalUsers = Convert.ToInt32(rd.GetInt32(1));
                    DataList.Add(data);

                }
            }
            return DataList;
        }
        public List<gClass1> GetWeeklyData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {

                SqlCommand cmd = new SqlCommand("SELECT DATEPART(yyyy,t1.AccessedDate) AS OrderYear,DATEPART(MM,t1.AccessedDate) AS OrderM,DATEPART(WW,t1.AccessedDate) AS OrderD, t2.ApplicationName,COUNT(t1.ApplicationID) FROM dbo.AccessDetails as t1 inner join dbo.Application as t2 on t1.ApplicationID=t2.ApplicationID group by ApplicationName,DATEPART(yyyy,t1.AccessedDate),DATEPART(MM,t1.AccessedDate),DATEPART(WW,t1.AccessedDate) order by DATEPART(yyyy,t1.AccessedDate),DATEPART(MM,t1.AccessedDate),DATEPART(WW,t1.AccessedDate)", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {

                    data = new gClass1();
                    //data.Year = Convert.ToDateTime(rd.GetDateTime(4));
                    data.Month = Convert.ToDateTime(rd.GetDateTime(4));
                    data.Week = Convert.ToDateTime(rd.GetDateTime(4));
                    data.AppName = Convert.ToString(rd.GetSqlValue(0));

                    data.TotalUsers = Convert.ToInt32(rd.GetInt32(1));
                    DataList.Add(data);

                }
            }
            return DataList;
        }
        public List<gClass1> GetDailyData()
        {

            con.ConnectionString = "Data Source=PC348892;Initial Catalog=AccessDatabase;Integrated Security=True";

            con.Open();

            using (con)
            {

                SqlCommand cmd = new SqlCommand("SELECT DATEPART(yyyy,t1.AccessedDate) AS OrderYear,DATEPART(MM,t1.AccessedDate) AS OrderM,DATEPART(DD,t1.AccessedDate) AS OrderD, t2.ApplicationName,COUNT(t1.ApplicationID) FROM dbo.AccessDetails as t1 inner join dbo.Application as t2 on t1.ApplicationID=t2.ApplicationID group by ApplicationName,DATEPART(yyyy,t1.AccessedDate),DATEPART(MM,t1.AccessedDate),DATEPART(DD,t1.AccessedDate) order by DATEPART(yyyy,t1.AccessedDate),DATEPART(MM,t1.AccessedDate),DATEPART(DD,t1.AccessedDate)", con);
                //SqlCommand cmd = new SqlCommand("SELECT ApplicationID, COUNT(*) AS num FROM dbo.AccessDetails GROUP BY  ApplicationID", con);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {

                    data = new gClass1();
                    //data.Year = Convert.ToDateTime(rd.GetDateTime(4));
                    data.Month = Convert.ToDateTime(rd.GetDateTime(4));
                    data.Day = Convert.ToDateTime(rd.GetDateTime(4));
                    data.AppName = Convert.ToString(rd.GetSqlValue(0));

                    data.TotalUsers = Convert.ToInt32(rd.GetInt32(1));
                    DataList.Add(data);

                }
            }
            return DataList;
        }
    }
}