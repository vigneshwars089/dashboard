(cviz.jQuery, d3), window.cviz || (cviz = {}), cviz.widget || (cviz.widget = {}), cviz.widget.Sunburst = function(t, e, n) {
		
	    var i = function(i) {
		
            function r(t) {
                var e;
                for (e = 0; e < t.length; e++)
                    if (t.indexOf(t[e]) !== t.lastIndexOf(t[e])) return !1;
                return !0
            }

            function a(t) {
                var e = {},
                    n = [];
                return U.forEach(function(i) {
                    t.forEach(function(t) {
					
                        -1 === n.indexOf(t[i]) && (n.push(t[i]), e[t[i]] = I ? I[t[i]] : V(t[i]))
                    })
                }), e
            }

            function o(t) {
                return t.children ? Math.max.apply(Math, t.children.map(o)) : t.y + t.dy
            }

            function l(t) {
			
                var n = o(t),
                    i = e.interpolate(N.domain(), [t.x, t.x + t.dx]),
                    r = e.interpolate(P.domain(), [t.y, n]),
                    a = e.interpolate(P.range(), [t.y ? F : 0, w]);
                return function(t) {
                    return function(e) {
                        return N.domain(i(e)), P.domain(r(e)).range(a(e)), R(t)
                    }
                }
            }

            function s(t) {
                L && t.forEach(function(t) {
                    t[L] < 0 && cviz.Logger.WarnLogger.log(j, "602", "In a given record " + JSON.stringify(t) + " '" + L + "' field is negative. So pie is not drawn for the corresponding value.")
                })
            }

            function c(t) {
                k = t - O.right - O.left, w = Math.min(k, z) / 2, e.select(A).select("svg.sunburst").remove(), e.select(A).selectAll("div.cviz-common.tool-tip").remove(), P = e.scale.pow().exponent(1.3).domain([0, 1]).range([0, w]), i.tooltip && (i.tooltip.container = A, i.tooltip.margin = O, i.tooltip.containerWidth = t, C = cviz.Tooltip.Panel(i && i.tooltip), T = i.tooltip.title || "Total Counts", S = i.tooltip.name || "All Records"), M = e.select(A).append("svg").attr("id", "sunburst").attr("class", "sunburst").attr("width", t).attr("height", v).append("g").attr("transform", "translate(" + (k / 2 + O.left) + "," + (z / 2 + O.top) + ")"), i.container.title && M.append("text").attr("class", "title").attr("text-anchor", "middle").attr("x", 0).attr("y", q - O.top - w).text(""), F = P(.2)
            }

            function d(r) {
                function o(t) {
                    t.sort(function(t, e) {
                        return e.total - t.total
                    }), t.forEach(function(t) {
                        t.values && o(t.values)
                    })
                }
                var d, u, g, p, h, f = [],
                    m = [];
                y = e.select(window).node().innerWidth, b = t(A).width(), x >= b && (c(b), W = !0), B = t.extend(!0, [], r), d = t.extend(!0, [], r), i.container.title && M.select(".title").text(i.container.title), Y = a(r), s(d), u = U || [], g = e.nest(), u.forEach(function(t) {
                    g.key(function(e) {
					
                        return e[t]
                    })
                }), f = g.entries(d), p = function v(t) {
                    var e = 0;
                    return t && t.forEach(function(t) {
                        t.values && !t.values[0].values ? L ? (t.total = 0, t.values.forEach(function(e) {
                            t.total += e[L] || 0
                        }), 0 === t.total && t.values.length > 0 && 0 !== t.values[0][L] && (t.total = t.values.length)) : t.total = t.values.length : t.total = v(t.values), e += t.total;
						
						
                    }), e
                }(f), o(f), h = M.data([{
                    key: S,
                    values: f,
                    total: p
					
                }]).selectAll("path").data(D.nodes).enter().append("path").attr("display", function(t) {
				
                    return t.depth < U.length + 1 ? null : "none"
                }).attr("d", R).attr("fill-rule", "evenodd").style("fill-opacity", function(t) {
                    return 0 === t.depth ? 0 : null
                }).style("fill", function(t) {
                    if (0 === t.depth) return "white";
                    if (1 === t.depth && I) {
                        var n = I ? I[t.key] : V(t.key);
                        n && (t.color = n)
                    }
                    return t.color ? t.color : (t.color = t.depth > 1 ? e.rgb(t.parent.color).brighter(.15 + .06 * t.parent.values.indexOf(t)) : I ? I[(t.values ? t : t.parent).key] : V((t.values ? t : t.parent).key), t.color)
                }).on("mouseover", function(t) {
                    e.select(this).style("stroke", "#000").style("stroke-width", .2);
					
					
			
                    var n = "<div>" + t.key + "</div><div>" + T + ": " + t.total + "</div>";
                    i.tooltip && C.show(t, n)
                }).on("mousemove", function() {
                    var n = e.mouse(E);
                    i.tooltip && C.updatePosition(n[0], n[1], t(A).width(), t(A).height())
                }).on("mouseout", function() {
                    e.select(this).style("stroke", null), i.tooltip && C.hide()
                }).on("click", function(t) {
				
                    var i, a, o, s;
					
                    0 === t.depth ? (i = [], r.forEach(function(t) {
                        var e, n;
                        a = {};
                        for (e in t) "object" != typeof t[e] && t[e] && t[e].constructor !== Array && (a[e] = t[e]);
						
                        n = a, delete n.depth, delete n.dx, delete n.dy, delete n.x, delete n.y, i.push(n)
                    }), n.publish(G + "sunburst-pie-select", i)) : (o = [], s = function(t) {
                        t.depth === U.length ? t.values.forEach(function(t) {
                            var e, n;
                            a = {};
                            for (e in t) "object" != typeof t[e] && t[e] && t[e].constructor !== Array && (a[e] = t[e]);
						
							
                            n = a, delete n.depth, delete n.dx, delete n.dy, delete n.x, delete n.y, o.push(n)
                        }) : t.values.forEach(function(t) {
						
                            s(t)
                        })
						
                    }, s(t), n.publish(G + "sunburst-pie-select", e.merge([o]))), h.transition().duration(_).attrTween("d", l(t))
                }).on("touchstart", function(a) {
                    var o = e.select(this);
                    e.selectAll("path").style("stroke", null), cviz.MobileUtils.handleTouchStart(function(e) {
                        o.style("stroke", "#000").style("stroke-width", .2);
                        var n = "<div>" + a.key + "</div><div>" + T + ": " + a.total + "</div>";
                        C.updatePosition(e[0], e[1], t(A).width(), t(A).height()), i.tooltip && C.show(a, n)
                    }, function() {
                        i.tooltip && C.hide();
                        var t, o, s, c;
                        0 === a.depth ? (t = [], r.forEach(function(e) {
                            var n, i;
                            o = {};
                            for (n in e) "object" != typeof e[n] && e[n] && e[n].constructor !== Array && (o[n] = e[n]);
                            i = o, delete i.depth, delete i.dx, delete i.dy, delete i.x, delete i.y, t.push(i)
                        }), n.publish(G + "sunburst-pie-select", t)) : (s = [], c = function(t) {
                            t.depth === U.length ? t.values.forEach(function(t) {
                                var e, n;
                                o = {};
                                for (e in t) "object" != typeof t[e] && t[e] && t[e].constructor !== Array && (o[e] = t[e]);
                                n = o, delete n.depth, delete n.dx, delete n.dy, delete n.x, delete n.y, s.push(n)
                            }) : t.values.forEach(function(t) {
                                c(t)
                            })
                        }, c(a), n.publish(G + "sunburst-pie-select", e.merge([s]))), h.transition().duration(_).attrTween("d", l(a))
                    }, E)
                }), d.forEach(function(t) {
				
                    var e, n, i = {};
                    for (e in t) "object" != typeof t[e] && t[e] && t[e].constructor !== Array && (i[e] = t[e]);
                    n = i, delete n.depth, delete n.dx, delete n.dy, delete n.x, delete n.y, m.push(n)
                }), n.publish(G + "sun-burst-render-complete", {
                    data: m,
                    colorObject: Y
					
                })
            }

            function u(t) {
                c(t), d(B)
            }

            function g() {
                y !== e.select(window).node().innerWidth && b !== t(A).width() && (y = e.select(window).node().innerWidth, b = t(A).width(), x >= b ? (u(b), W = !0) : W && (u(x), W = !1))
            }

            function p(t, e) {
                cviz.Print.doPrint(A, t, e)
            }

            function h(t, e, n, i) {
                var r = {
                    cssUrl: n,
                    exportServiceUrl: e,
                    fileName: i
                };
                cviz.Menu.download(t, A, r, null, B, null)
            }

            function f() {
                return {
                    render: function(t) {
                        return d(t), f
                    },
                    print: function(t, e) {
                        t = t || "landscape", e = e || "5mm", p(t, e)
                    },
                    download: function(t, e, n, i) {
                        h(t, e, n, i)
                    },
					getDataKeys: function(){
					return i.bindings.keys;
					}
					
                }
            }
            var m, v, x, y, b, w, k, z, L, A, N, P, E, C, T, M, S, D, R, F, I, B, 
			O = {
                    top: 10,
                    left: 10,
                    bottom: 10,
                    right: 10
                },
                W = !1,
                U = [],
                q = 10,
                _ = 1e3,
                V = cviz.Palette.colors ? cviz.Palette.Picker() : e.scale.category10(),
                j = "sun-burst",
                G = "",
                Y = {};
            return 1 !== arguments.length && cviz.Logger.ErrorLogger.log(j, "201", "Invalid configuration to create Sun Burst ! "), 
			I = i.colors, 
			j = i.id ? i.id + "-sun-burst" : "sun-burst", 
			G = i.id ? i.id + "-" : "", 
			i.container && i.container.id ? A = i.container.id : cviz.Logger.ErrorLogger.log(j, "202", "Container id is mandatory. Please provide a valid container id."), 
			i.container && i.container.width && !isNaN(i.container.width) ? m = x = Number(i.container.width) : cviz.Logger.ErrorLogger.log(j, "204", "Container width is mandatory. Please provide a valid container width in pixels."), 
			i.container && i.container.height && !isNaN(i.container.height) ? v = Number(i.container.height) : cviz.Logger.ErrorLogger.log(j, "204", "Container height is mandatory. Please provide a valid container height in pixels."), 
			i.margin && (O.top = parseInt(i.margin.top, 10), O.right = parseInt(i.margin.right, 10), O.bottom = parseInt(i.margin.bottom, 10), O.left = parseInt(i.margin.left, 10)), 
			k = m - O.right - O.left, 
			z = v - O.top - O.bottom, 
			w = Math.min(k, z) / 2, 
			i.bindings || cviz.Logger.ErrorLogger.log(j, "203", "Bindings are mandatory for drawing widget Please provide appropriate bindings."),
			i.bindings.keys || cviz.Logger.ErrorLogger.log(j, "203", " Mandatory parameter keysmissing in the configuration. Please provide them."), 
			r(i.bindings.keys) || cviz.Logger.ErrorLogger.log(j, "330", "The axis keys binding should have unique values."), 
			U = i.bindings.keys, 
			i.bindings.bindingValue && (L = i.bindings.bindingValue), 
			i.container && i.container.titlePos && (q = i.container.titlePos, 0 > q && cviz.Logger.WarnLogger.log(j, "505", "Title position cannot be negative. Please provide positive value.")), 
			this.getData = function() {
			
                return B
            }, 
			N = e.scale.linear().range([0, 2 * Math.PI]), 
			P = e.scale.pow().exponent(1.3).domain([0, 1]).range([0, w]), 
			E = e.select(A).node(), 
			i.tooltip && (i.tooltip.container = A, i.tooltip.margin = O, i.tooltip.containerWidth = m, C = cviz.Tooltip.Panel(i && i.tooltip), T = i.tooltip.title || "Total Count", S = i.tooltip.name || "All Records"), 
			cviz.Menu.menuConfig(i, A, this), 
			M = e.select(A).append("svg").attr("id", "sunburst").attr("class", "sunburst").attr("width", m).attr("height", v).append("g").attr("transform", "translate(" + (k / 2 + O.left) + "," + (z / 2 + O.top) + ")"), 
			i.container.title && M.append("text").attr("class", "title").attr("text-anchor", "middle").attr("x", 0).attr("y", q - O.top - w).text(""), 
			D = e.layout.partition().sort(null).value(function(t) {
                return L ? t[L] : 5.8 - t.depth
            }).children(function(t) {
                return t.values
            }), R = e.svg.arc().startAngle(function(t) {
                return Math.max(0, Math.min(2 * Math.PI, N(t.x)))
            }).endAngle(function(t) {
                return Math.max(0, Math.min(2 * Math.PI, N(t.x + t.dx)))
            }).innerRadius(function(t) {
                return Math.max(0, t.y ? P(t.y) : t.y)
            }).outerRadius(function(t) {
                return Math.max(0, P(t.y + t.dy))
            }), F = P(.2), e.select(window).on("resize.sunburst" + i.id, g), {
                graph: f
            }
        };
        return {
            Runner: i
        }
    }