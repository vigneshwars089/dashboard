var dynamicTableData = [];

var dynamicTableOptions = {
        container : {
				id : "#tbl",
				filterable: false
			},
        columnBindings : [],
		headerBindings : {},
		dataTypeBindings: {},
			classes : {
				 "table" : "table table-bordered",
				 "pager" : "pagination" 
			},
			pager:{
					pagerLength: 3,
					recordsPerPage: 7,
					position: "bottom", //"top" or "bottom"
					align: "center" // "left" or "right" or "center" or 
			},
			utility:{
				print:{
					isPrintable:false,
					pageSize:'landscape',//l=landscape;p=portrait;or give width & height
					pageMargin:{
						top:1,
						right:1,
						bottom:1,
						left:1,
						unit:'cm'//in-inch or mm-millimeter or cm-centimeter 
					}
				},
				download:{
					cssFileUrl : 'http://visualization-coe.cognizant.com/widgets/dynamic-table/dynamic-table.css',
					exportServiceUrl : 'http://visualization-coe.cognizant.com/cviz-utilities/export',
					fileName: 'demotest'
					
				}
			}	
}


function initTable(data){
		createTableData(data);
		createTableOptions(data);
}

function createTableData(data){
	dynamicTableData = data;
}

function createTableOptions(data){
	var columnBindingArr = [];
	
	var headerBindingsObj = {};
	
	var dataTypeBindingsObj = {}
	
	var sampleDataObj = data[0];
	
	
	for(var i in sampleDataObj)	{
		columnBindingArr.push(i);
		headerBindingsObj[i] = String(i).toUpperCase();
		dataTypeBindingsObj[i] =  typeof(i);
	}
	dynamicTableOptions.columnBindings = columnBindingArr;
	dynamicTableOptions.headerBindings = headerBindingsObj;
	dynamicTableOptions.dataTypeBindings = dataTypeBindingsObj;
	
}